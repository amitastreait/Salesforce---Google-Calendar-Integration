({
	doInit : function(component, event, helper) {
        component.set('v.isSending', true);
		var action = component.get('c.fetchCustomMetadata');
        
        action.setCallback(this, function(response){
            var state = response.getState();
            
            if(state === 'SUCCESS' && component.isValid()){
                var responseValue = response.getReturnValue();
                component.set('v.customMetaDataRec' , responseValue);
                component.set('v.isSending', false);
            }
        });
        $A.enqueueAction(action);
	},
    updateMetadataRecord : function(component, event, helper) {
        var test = component.get('v.customMetaDataRec');
        var isToggleCheck = test.mwidget__IsToggleContacts__c;

        component.set('v.isSending', false);
        var action = component.get('c.updateMetaData');
        action.setParams({
            "cuastomMetadataRecord" : test
        });
        action.setCallback(this, function(repsonse){
            var state = repsonse.getState();
            if(state === 'SUCCESS' && component.isValid()){
                var resultsToast = $A.get("e.force:showToast");
                component.set('v.isSending', true);
                resultsToast.setParams({
                    "title": "Updated",
                    "type" : "success",
                    "message": "The Meeting Widget has been Updated."
                });
                resultsToast.fire();
                component.set('v.isSending', false);
                $A.get('e.force:refreshView').fire();
            }
        });
        $A.enqueueAction(action);
    },
    getTogleValue : function(component, event, helper) {
        
    }
})