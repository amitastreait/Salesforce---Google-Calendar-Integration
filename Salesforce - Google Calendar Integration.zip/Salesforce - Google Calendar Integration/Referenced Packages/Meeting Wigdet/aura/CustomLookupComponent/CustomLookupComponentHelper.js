({
	bindContactList : function(component, event, selectedContactListVar, usersList) {
        var appEvent = $A.get("e.mwidget:CustomLookupEvent");
        appEvent.setParams({ 
            "contactsList" : selectedContactListVar ,
            "usersList" : usersList
        });
        appEvent.fire();
	}
})