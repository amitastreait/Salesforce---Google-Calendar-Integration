({
    handleApplicationEvent : function(component, event, helper) {
        var searchParamFromEvent = event.target.value;
        if(searchParamFromEvent.length>0){
            if(searchParamFromEvent === 'default'){
                
            }else{
                var action = component.get("c.searchObjects");
                action.setParams({
                    "nameParam": searchParamFromEvent
                });
                
                action.setCallback(this, function(response){
                    var state = response.getState();
                    if(state === 'SUCCESS' && component.isValid()){
                        var accountList = response.getReturnValue();
                        component.set('v.showSearchedAccounts',true);
                        if(accountList.length>0){
                            component.set('v.accountList',accountList);
                        }else{
                            var accList = component.get('v.accountList');
                            accList = [];
                            component.set('v.accountList',accList);
                        }
                    }else if(state === 'ERROR'){
                        console.log(response.error);
                    }else{
                        console.log('unknown error');
                    }
                });
                $A.enqueueAction(action);
            }
        }else{
            var accList = component.get('v.accountList');
            accList = [];
            component.set('v.accountList',accList);
        }
    },
    selectAccount : function(component, event, helper){
        var clickedAccountId = event.target.id;
        var idNameList = clickedAccountId.split('#');
        component.set('v.showSearchedAccounts',false);
        component.set('v.selectedAccountId',idNameList[1]);
        var selectedAccountListVar = component.get('v.selectedAccountList');
        selectedAccountListVar.push({ key:idNameList[0],value:idNameList[1]});
        component.set('v.selectedAccountList',selectedAccountListVar);
        
        /* in the Last Execute the Event to Bind the value in Parent Component */
        var contactList = component.get('v.selectedcontactList');
        helper.bindContactList(component, event, contactList, selectedAccountListVar);
        
    },
    clear  : function(component,event,helper){
        var clickedAccountId = event.target.id;
        var listOptions=[];
        var selectedAccountListVar = component.get('v.selectedAccountList');
        if(selectedAccountListVar==null || selectedAccountListVar.length==1){
            component.set('v.selectedAccountId',null);
        }
        for(var i=0; i< selectedAccountListVar.length; i++){
            
            if(selectedAccountListVar[i].key!=clickedAccountId){
                 
                 listOptions.push({ key:selectedAccountListVar[i].key,value:selectedAccountListVar[i].value});
            }
        }
       
       component.set('v.selectedAccountList',listOptions);
    },
    /* Search Contacts Start */
    handleApplicationEventContact : function(component, event, helper) {
        var searchParamFromEvent = event.target.value;
        if(searchParamFromEvent.length>0){
            if(searchParamFromEvent === 'default'){
                
            }else{
                var togleCheckVal = component.get('v.isTogleCheck');
                var action = component.get("c.searchObjectsContacts");
                action.setParams({
                    "nameParam": searchParamFromEvent,
                    "isUnrelatedContacts" : togleCheckVal,
                    "accountId" : component.get('v.accountId')
                });
                
                action.setCallback(this, function(response){
                    var state = response.getState();
                    if(state === 'SUCCESS' && component.isValid()){
                        var contactList = response.getReturnValue();
                        component.set('v.showSearchedContacts',true);
                        if(contactList.length>0){
                            component.set('v.contactList',contactList);
                        }else{
                            var accList = component.get('v.contactList');
                            accList = [];
                            component.set('v.contactList',accList);
                        }
                    }else if(state === 'ERROR'){
                        console.log(response.error);
                    }else{
                        console.log('unknown error');
                    }
                });
                $A.enqueueAction(action);
            }
        }else{
            var accList = component.get('v.contactList');
            accList = [];
            component.set('v.contactList',accList);
        }
    },
    selectContact : function(component, event, helper){
        var clickedContactId = event.target.id;
        var idNameList = clickedContactId.split('#');
        component.set('v.showSearchedContacts',false);
        component.set('v.selectedContactId',idNameList[1]);
        var selectedContactListVar = component.get('v.selectedcontactList');
        selectedContactListVar.push({ key:idNameList[0],value:idNameList[1]});
        component.set('v.selectedcontactList',selectedContactListVar);
        
        /* in the Last Execute the Event to Bind the value in Parent Component */
        var usersList = component.get('v.selectedAccountList');
        helper.bindContactList(component, event, selectedContactListVar, usersList);
    },
    clearContact  : function(component,event,helper){
        var clickedContactId = event.target.id;
        var listOptions=[];
        var selectedContactListVar = component.get('v.selectedcontactList');
        if(selectedContactListVar == null || selectedContactListVar.length == 1){
            component.set('v.selectedContactId',null);
        }
        for(var i=0; i< selectedContactListVar.length; i++){
            
            if(selectedContactListVar[i].key!=clickedContactId){
                 
                 listOptions.push({ key:selectedContactListVar[i].key,value:selectedContactListVar[i].value});
            }
        }
       
       component.set('v.selectedcontactList',listOptions);
    },
    /* Search Contacts End */
    
    // automatically call when the component is done waiting for a response to a server request.  
    hideSpinner : function (component, event, helper) {
        var spinnerComponent = component.find('showSpinner1');
        if(spinnerComponent!=undefined){
            var evt = spinnerComponent.get("e.toggle");
            evt.setParams({ isVisible : false });
            evt.fire();
        }
    },
    // automatically call when the component is waiting for a response to a server request.
    showSpinner : function (component, event, helper) {
        var spinnerComponent = component.find('showSpinner1');
        if(spinnerComponent!=undefined){
            var evt = spinnerComponent.get("e.toggle");
            evt.setParams({ isVisible : true });
            evt.fire();
        }
    },
    getTogleValue : function (component, event, helper) {
        var valueCheckbox = document.getElementById('togleCheck').checked;
        component.set('v.isTogleCheck', valueCheckbox);
    },   
    
})