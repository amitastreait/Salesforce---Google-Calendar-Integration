({
	doInit : function(component, event, helper) {
        component.set('v.isSending' , true);
		helper.getNewMeetingTemplate(component, event);
        component.set('v.isSending' , false);
        var action = component.get('c.CustomSettingDetails');
        action.setCallback( this, function(response){
            var state = response.getState();
            if(state === 'SUCCESS' && component.isValid()){
                var responseValue = response.getReturnValue();
                component.set('v.customSettingData' , responseValue);
            }
        });
        $A.enqueueAction(action);
	},
    handleCreateMeeting : function(component, event, helper) {
		helper.handleSaveMeeting(component, event);
	}, 
    handleApplicationEvent : function(component, event, helper) {
        var contactList = event.getParam("contactsList");
        var userList = event.getParam("usersList");
        component.set('v.contactList' , contactList);
        component.set('v.userList' , userList);
    },
    
    handleAgendaAppLink : function(component, event, helper){
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "http://www.salesforcewidgets.com/"
        });
        urlEvent.fire();
    },
})