({
    getNewMeetingTemplate : function(component, event) {
        // Prepare a new record from template
        component.find("forceMeetingRecord").getNewRecord(
            "mwidget__Meetings__c", 
            null,      
            false,    
            $A.getCallback(function() {
                var rec = component.get("v.meetingRecord");
                var error = component.get("v.meetingRecordError");
                if(error || (rec === null)) {
                    console.log("Error initializing record template: " + error);
                }
                else {
                    console.log("Record template initialized: " + rec.sobjectType);
                    var resultsToast = $A.get("e.force:showToast");
                    resultsToast.setParams({
                        "title": "Initiated",
                        "message": "New Record Template Initiated!"
                    });
                    //resultsToast.fire();
                }
            })
        );
    },
    
    validateMeetingForm : function(component, event) {
        var validMeeting = true;
        var allValid = true;
        
        
        if(allValid){
            var startTimeCmp = component.find('startTime');
            var startTimevalue = startTimeCmp.get('v.value');
            
            var endTimeCmp = component.find('endTime');
            var endTimevalue = endTimeCmp.get('v.value');
            
            if(startTimevalue == undefined || startTimevalue == null){
                component.set('v.hasError' , true);
                validMeeting = false;
            }else{
                component.set('v.hasError' , false);
            }
            
            if(endTimevalue == undefined || endTimevalue == null){
                component.set('v.hasError' , true);
                validMeeting = false;
            }else{
                component.set('v.hasError' , false);
            }
            
            return validMeeting;
        }else{
            component.set('v.isSending' , false);
            return false;
        }
    },
    
    handleSaveMeeting : function(component, event) {
        component.set('v.isSending' , false);
        var url = location.href;  
        var baseURL = url.substring(0, url.indexOf('/', 14));
        if(true) {
            component.set("v.meetingRecord.mwidget__Account__c", component.get("v.recordId"));
            var isDateTimeDate = component.get('v.customSettingData');
            var isDateTime = isDateTimeDate.mwidget__IsMeetingDateTime__c;
            var isUsers = isDateTimeDate.mwidget__IsUsers__c;
            var isContacts = isDateTimeDate.mwidget__IsContacts__c;
            var isNotes = isDateTimeDate.mwidget__IsNotes__c;
				
            if(isUsers === true){
                var userList = component.get('v.userList');
                var userNameList ='';
                var userIdsList ='';
                
                for(var i=0; i< userList.length; i++){
                    userIdsList+= userList[i].key + ',';
                    userNameList+= userList[i].value+ ',';
                }
                
                component.set("v.meetingRecord.mwidget__Meeting_User_Names__c", userNameList);
                component.set("v.meetingRecord.mwidget__Meeting_Users_Ids__c", userIdsList);
            }            
            
            if(isContacts === true){
                var contactList = component.get('v.contactList');
                var contactNameList='';
                var contactIdsList='';
                
                for(var i=0; i< contactList.length; i++){
                    contactIdsList+= contactList[i].key+',';
                    contactNameList+= contactList[i].value+',';
                }
                
                component.set("v.meetingRecord.mwidget__Meeting_Contacts_Name__c", contactNameList);
                component.set("v.meetingRecord.mwidget__Meeting_Contacts__c", contactIdsList);
            }
            
            if(isDateTime === true){
                var startTimeCmp = component.find('startTime').get('v.value');
                var endTimeCmp = component.find('endTime').get('v.value');
                
                var splitTimeStart = startTimeCmp.split(':')[0];
                var splitTimeEnd = endTimeCmp.split(':')[0];
                
                var startTimeInsert;
                var endTimeInsert;
                
                if(parseInt(splitTimeStart)>=12){
                    if(parseInt(splitTimeStart)==12){
                        startTimeInsert = (parseInt(startTimeCmp))+':'+startTimeCmp.split(':')[1]+' PM';
                    }else{
                        startTimeInsert = (parseInt(startTimeCmp) - 12)+':'+startTimeCmp.split(':')[1]+' PM';
                    }
                }else{
                    startTimeInsert =  startTimeCmp + ' AM';
                }
                if(parseInt(splitTimeEnd)>=12){
                    if(parseInt(splitTimeEnd)==12){
                        endTimeInsert = (parseInt(endTimeCmp))+':'+endTimeCmp.split(':')[1]+' PM';
                    }else{
                        endTimeInsert = (parseInt(endTimeCmp) - 12)+':'+endTimeCmp.split(':')[1]+' PM';
                    }
                    
                }else{
                    endTimeInsert = endTimeCmp + ' AM';
                }
                
                console.log(component.get("v.meetingRecord"));
                component.set("v.meetingRecord.mwidget__Meeting_Start_Time__c",startTimeInsert.toString());
                component.set("v.meetingRecord.mwidget__Meeting_End_Time__c", endTimeInsert.toString());
            }
            
            component.find("forceMeetingRecord").saveRecord(function(saveResult) {
                if (saveResult.state === "SUCCESS" || saveResult.state === "DRAFT") {
                    component.set('v.isSending' , false);
                    // record is saved successfully
                    var resultsToast = $A.get("e.force:showToast");
                    resultsToast.setParams({
                        "title": "Saved",
                        "type" : "success",
                        "message": "The Meeting record saved.",
                        messageTemplate: 'Record {0} created! See it {1}!',
                        messageTemplateData: ['Meeting', {
                            url: baseURL+'/'+saveResult.recordId,
                            label: 'here',
                        }
                                             ]
                    });
                    resultsToast.fire();
                    $A.get('e.force:refreshView').fire();
                    
                } else if (saveResult.state === "INCOMPLETE") {
                    // handle the incomplete state
                    component.set('v.isSending' , false);
                    console.log("User is offline, device doesn't support drafts.");
                } else if (saveResult.state === "ERROR") {
                    // handle the error state
                    component.set('v.isSending' , false);
                    console.log('Problem saving contact, error: ' + JSON.stringify(saveResult.error));
                } else {
                    component.set('v.isSending' , false);
                    console.log('Unknown problem, state: ' + saveResult.state + ', error: ' + JSON.stringify(saveResult.error));
                }
            }); 
            
        }
    },
})